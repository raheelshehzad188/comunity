UPDATE `general_settings` SET `value` = '2.4' WHERE `general_settings`.`type` = 'version';
INSERT INTO `business_settings` (`business_settings_id`, `type`, `status`, `value`) VALUES (NULL, 'bitcoin_set', null, 'no');
INSERT INTO `business_settings` (`business_settings_id`, `type`, `status`, `value`) VALUES (NULL, 'bitcoin_coinpayments_merchant', null, '');
ALTER TABLE `vendor` ADD `bitcoin_set` VARCHAR(500) NULL DEFAULT NULL, ADD `bitcoin_coinpayments_merchant` VARCHAR(500) NULL DEFAULT NULL ;
