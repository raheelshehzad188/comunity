UPDATE `general_settings` SET `value` = '2.3' WHERE `general_settings`.`type` = 'version';

