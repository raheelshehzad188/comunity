<!-- CSS Global -->
<link href="<?php echo base_url(); ?>template/front/plugins/owl-carousel2/assets/owl.carousel.min.css" rel="stylesheet">
<link href="<?php echo base_url(); ?>template/front/plugins/owl-carousel2/assets/owl.theme.default.min.css" rel="stylesheet">

<link href="<?php echo base_url(); ?>template/front/css/others/megamenu/theme-red.css" rel="stylesheet">
<link href="<?php echo base_url(); ?>template/front/css/others/megamenu/so_megamenu.css" rel="stylesheet">
<link href="<?php echo base_url(); ?>template/front/css/others/megamenu/responsive.css" rel="stylesheet">

<!-- Sidebar_menu JS -->
<script src="<?php echo base_url(); ?>template/front/css/others/megamenu/so_megamenu.js"></script>