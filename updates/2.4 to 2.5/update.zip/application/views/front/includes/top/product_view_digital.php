<link href="<?php echo base_url(); ?>template/front/plugins/owl-carousel2/assets/owl.carousel.min.css" rel="stylesheet">
<link href="<?php echo base_url(); ?>template/front/plugins/owl-carousel2/assets/owl.theme.default.min.css" rel="stylesheet">
<link rel="stylesheet" href="<?php echo base_url(); ?>template/front/js/share/jquery.share.css">
