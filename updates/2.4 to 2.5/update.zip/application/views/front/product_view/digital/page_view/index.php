<?php
	include 'product_detail.php';
?>
<?php
	include 'product_specification.php';
?>
